class LeagueOwner:

    def _init_(self, leagueOwnerID):
        self.ID = leagueOwnerID

