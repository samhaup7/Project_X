class League:

    def _init_(self, leagueID):
        self.ID = leagueID
