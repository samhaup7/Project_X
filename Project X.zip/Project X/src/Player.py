class Player:

    def _init_(self, playerID, points):
        self.ID = playerID
        self.point = points
