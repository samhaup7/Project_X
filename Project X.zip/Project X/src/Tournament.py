class Tournament:

    def _init_(self, tournamentID, tournStyleID, expertRatingFormulaID, playerList):
        self.ID = tournamentID
        self.styleID = tournStyleID
        self.erfID = expertRatingFormulaID
        self.players = playerList
        
