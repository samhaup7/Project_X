class LeagueOwnerController:

    """
    parameter - match is a object instantiated by class Match
    """
    def end_match(self, match):
        if match.match_is_ongoing == False
            return
        else
            match.match_is_ongoing = False
        
        
