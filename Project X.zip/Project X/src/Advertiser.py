class Advertiser:
    def _init_(self, ID):
        self.ID = ID
        
