class Developer:
    def _init_(self, developerID):
        self.ID = developerID
