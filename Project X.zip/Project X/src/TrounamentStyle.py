class TournamentStyle:

    def _init_(self, tournStyleID, styleName, rules):
        self.ID = tournStyleID
        self.name = styleName
        self.rule = rules
