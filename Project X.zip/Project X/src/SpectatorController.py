class SpectatorController:

    def update_spectate_link(self, newLink):
        self.link = newLink
