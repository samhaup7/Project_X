class MatchResult:

    def _init_(self, matchID, winnerName):
        self.ID = matchID
        self.winner = winnerName
